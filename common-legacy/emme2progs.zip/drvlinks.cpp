/*
 * DRVLINKS.C
 * written by   :  Tim Heier
 * last updated :  07/07/96
 */

#define VER          "2.00"
#define REL      " 7/07/96"
#define BIT            "32"

char *ProgName = "DRVLINKS";

/*
The basic program logic goes like this:

1. Start from a centroid and find all the nodes within the search values.
2. The canidate nodes are then sorted by distance from the centroid.
3. The node closest to the centroid is accepted into the final set.
4. Subsequent nodes are accepted into the final set if the multiple
	links option is on.
*/

#include "stdutil.h"
#include "ctlutil.h"
#pragma hdrstop
#include <condefs.h>


USEUNIT("stdutil.cpp");
USEUNIT("ctlutil.cpp");
//---------------------------------------------------------------------------
#define MAXSTR         120
#define CARTESIAN        0
#define MANHATTEN        1

FILE  *iptr, *rptr, *optr;

void  read_ini(void);
void  read_cents(void);
void  read_m2cents(void);
void  read_nodes(void);
void  read_m2nodes(void);
void  drvlinks(void);
void  write_link(long cent, long cnode, float dist);
void  usage(void);
void  run_header(void);
void  rpt_header(void);
void  pick_frto(char *tempbuf, int *from, int *to, int *length);

/* global variables */
int   CentCount, NodeCount, LinkCount;
char  *linebuf;
char  *iniFile, *CentroidFile, *NodeFile, *LinkFile, *ReportFile;

int   NumCentroids, NumNodes;
float NetworkScale,MinDistance,MaxDistance,DriveSpeed;

int   PrintUnconnected,PrintConnections,DryRun;
int   IndividualSearch,MultipleLinks;
int   FirstCentroid,FirstNode;

int   DeleteLinks,Distance;
char  NodeFormat,CentroidFormat,LinkFormat;

typedef struct {
	long   num;
	float  x;
	float  y;
	long   connected;
} cent_data;

typedef struct {
	long   num;
	float  x;
	float  y;
	float  mindist;
	float  maxdist;
	long   connected;
	float  padding2;
	float  padding3;
} node_data;

typedef struct {
	int    type;
	int    vdf;
	char   modesin[MAXSTR];
	char   modesout[MAXSTR];
	char   direction;
	float  lanes;
} link_data;

typedef struct {
	int    from;
	int    to;
	int    length;
} col_data;

cent_data  *cent;
node_data  *node;
link_data  newlink;
col_data   fnode, fnodex, fnodey, fnodeu1, fnodeu2;
col_data   fcent, fcentx, fcenty;

int main(int argc, char* argv[])
{

if(argc < 2) {
	usage();
	exit(1);
	}

/* allocate memory for strings */
CentroidFile = (char *) malloc(MAXSTR);
NodeFile     = (char *) malloc(MAXSTR);
LinkFile     = (char *) malloc(MAXSTR);
ReportFile   = (char *) malloc(MAXSTR);
iniFile      = (char *) malloc(MAXSTR);
linebuf      = (char *) malloc(MAXSTR);

/* allocate memory for character arrays */
if( (CentroidFile == NULL) || (NodeFile == NULL) || (LinkFile == NULL) ||
	 (ReportFile == NULL) || (iniFile == NULL) || (linebuf == NULL) ) {
	printf("\nerror: not enough memory to allocate string buffers\n");
	exit(1);
	}

strcpy(iniFile,argv[1]);

run_header();
read_ini();

if(DryRun)
	exit(1);

/* allocate memory for data */
if( (cent = (cent_data *) calloc( NumCentroids+1, sizeof(cent_data))) == NULL ) {
	printf("\nerror: allocating centroid buffer\n");
	exit(1);
			}
if( (node = (node_data *) calloc( NumNodes+1, sizeof(node_data))) == NULL ) {
	printf("\nerror: allocating node buffer\n");
	exit(1);
	}

if(CentroidFormat == 'e')
	read_m2cents();
else
	read_cents();

if(NodeFormat == 'e')
	read_m2nodes();
else
	read_nodes();

fprintf(rptr,"\nRUN RESULTS\n");
fprintf(rptr,  "------------\n");
fprintf(rptr,"\nCENTROIDS READ = %d\n",CentCount);
fprintf(rptr,  "NODES READ     = %d\n",NodeCount);

drvlinks();

return(0);
}

/*************************************************************************/
void read_ini(void)
{
char c, tempbuf[MAXSTR];

/* FILES Section */
strcpy(linebuf,"Files");
GetPrivateProfileString(linebuf,"CentroidFile","cents.in",
			CentroidFile, iniFile);
GetPrivateProfileString(linebuf,"NodeFile","nodes.in",
			NodeFile, iniFile);
GetPrivateProfileString(linebuf,"LinkFile","drvlinks.out",
			LinkFile, iniFile);
GetPrivateProfileString(linebuf,"ReportFile","drvlinks.rpt",
			ReportFile, iniFile);

/* open report file */
if( (rptr = fopen(ReportFile,"w")) == NULL ) {
	printf("\nerror: opening file \"%s\" for writing.", ReportFile);
	exit(1);
	}
rpt_header();

/* open control file */
if( (iptr = fopen(iniFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.", iniFile);
	exit(1);
	}

/* echo control file to report file */
fprintf(rptr,"\nCONTROL FILE\n");
fprintf(rptr,  "-------------\n\n");
while( (c = getc(iptr) ) != EOF)
	putc(c, rptr);
fclose(iptr);

/* PARAMETERS Section */
strcpy(linebuf,"Parameters");
NumCentroids =
	GetPrivateProfileInt(linebuf,"NumCentroids",2000,iniFile);
NumNodes =
	GetPrivateProfileInt(linebuf,"NumNodes",500,iniFile);
MinDistance =
	GetPrivateProfileFloat(linebuf,"MinDistance",0.0,iniFile);
MaxDistance =
	GetPrivateProfileFloat(linebuf,"MaxDistance",3.0,iniFile);
NetworkScale =
	GetPrivateProfileFloat(linebuf,"NetworkScale",1.0,iniFile);
MultipleLinks =
	GetPrivateProfileBool(linebuf,"MultipleLinks",1,iniFile);
IndividualSearch =
	GetPrivateProfileBool(linebuf,"IndividualSearch",0,iniFile);
DriveSpeed =
	GetPrivateProfileFloat(linebuf,"DriveSpeed",20.0,iniFile);

GetPrivateProfileString(linebuf,"Distance","cartesian",
			tempbuf, iniFile);
if(toupper(tempbuf[0]) == 'C')
	Distance = CARTESIAN;
else
	Distance = MANHATTEN;

if(NetworkScale == 0) {
	printf("\nerror: parameter *NetworkScale* cannot be zero.\n");
	exit(1);
	}

/* REPORTS Section */
strcpy(linebuf,"Reports");
PrintUnconnected =
	GetPrivateProfileBool(linebuf,"PrintUnconnected",1,iniFile);
PrintConnections =
	GetPrivateProfileBool(linebuf,"PrintConnections",1,iniFile);

/* undocumented options */
DryRun =
	GetPrivateProfileInt(linebuf,"DryRun",0,iniFile);

/* CENTROID FORMAT Section */
strcpy(linebuf,"Centroid Format");
GetPrivateProfileString(linebuf,"CentroidFormat","u",
			tempbuf, iniFile);
CentroidFormat = tolower(tempbuf[0]);
if( (CentroidFormat != 'u') && (CentroidFormat != 'e') ) {
	printf("\nerror: invalid *CentroidFormat* entry = %c\n",CentroidFormat);
	exit(1);
	}

if(CentroidFormat == 'u') {
	GetPrivateProfileString(linebuf,"Number","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcent.from, &fcent.to, &fcent.length);

	GetPrivateProfileString(linebuf,"XCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcentx.from, &fcentx.to, &fcentx.length);

	GetPrivateProfileString(linebuf,"YCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcenty.from, &fcenty.to, &fcenty.length);
	}

FirstCentroid = GetPrivateProfileInt(linebuf,"FirstCentroid",1,iniFile);

/* NODE FORMAT Section */
strcpy(linebuf,"Node Format");
GetPrivateProfileString(linebuf,"NodeFormat","u",
			tempbuf, iniFile);
NodeFormat = tolower(tempbuf[0]);
if( (NodeFormat != 'u') && (NodeFormat != 'e') ) {
	printf("\nerror: invalid *NodeFormat* entry = %c\n",NodeFormat);
	exit(1);
	}

if(NodeFormat == 'u') {
	GetPrivateProfileString(linebuf,"Number","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnode.from, &fnode.to, &fnode.length);
	GetPrivateProfileString(linebuf,"XCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodex.from, &fnodex.to, &fnodex.length);
	GetPrivateProfileString(linebuf,"YCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodey.from, &fnodey.to, &fnodey.length);
	GetPrivateProfileString(linebuf,"User1","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodeu1.from, &fnodeu1.to, &fnodeu1.length);
	GetPrivateProfileString(linebuf,"User2","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodeu2.from, &fnodeu2.to, &fnodeu2.length);
	}

FirstNode = GetPrivateProfileInt(linebuf,"FirstNode",1,iniFile);

/* NEW LINK ATTRIBUTES Section */
strcpy(linebuf,"New Link Attributes");
DeleteLinks =
	GetPrivateProfileBool(linebuf,"DeleteLinks",0,iniFile);
newlink.lanes =
	GetPrivateProfileFloat(linebuf,"Lanes",1.0,iniFile);
newlink.type =
	GetPrivateProfileInt(linebuf,"LinkType",99,iniFile);
newlink.vdf =
	GetPrivateProfileInt(linebuf,"VolumeDelay",99,iniFile);

/* check for old "modes" entry for one-way links */
GetPrivateProfileString(linebuf,"Modes","",
	newlink.modesout, iniFile);
if(strlen(newlink.modesout) >= 1)
	newlink.direction = 'o';
else {
	GetPrivateProfileString(linebuf,"ModesIn","p",
		newlink.modesin, iniFile);
	GetPrivateProfileString(linebuf,"ModesOut","q",
		newlink.modesout, iniFile);
	GetPrivateProfileString(linebuf,"Direction","outbound",
		tempbuf, iniFile);
	}

GetPrivateProfileString(linebuf,"LinkFormat","u",
			tempbuf, iniFile);
LinkFormat = tolower(tempbuf[0]);
if( (LinkFormat != 'e') && (LinkFormat != 't') && (LinkFormat != 'i') ) {
	printf("\nerror: invalid *LinkFormat* entry = %s\n",tempbuf);
	exit(1);
	}

/* check link entries */

newlink.direction = tolower(newlink.direction);
if( (newlink.direction != 't') && (newlink.direction != 'i') &&
		(newlink.direction != 'o') ) {
	printf("\nerror: invalid *Direction* entry = %s\n",tempbuf);
	exit(1);
	}

if(MinDistance > MaxDistance) {
	printf("\nerror: The Minimum search distance is greater then the Maximum.\n");
	exit(1);
	}

if( (LinkFormat == 't') || (LinkFormat == 'i') ) {
	DeleteLinks = FALSE;
	}

}

/*************************************************************************/
void read_cents(void)
{
int  lines;

CentCount = lines = 0;

if( (iptr = fopen(CentroidFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",CentroidFile);
	exit(1);
	}

while( (lines+1) < FirstCentroid) {
	fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

while( (fget_line(&linebuf[1],MAXSTR,iptr)) != EOF) {
	lines++;
	if(strlen(&linebuf[1]) > 5) {
		CentCount++;
		if(CentCount > NumCentroids) {
			printf("\nerror: more than %d centroids found.\n", NumCentroids);
			exit(1);
			}

		cent[CentCount].num = getlong(&linebuf[1],fcent.from,fcent.length);
		cent[CentCount].x   = getfloat(&linebuf[1],fcentx.from,fcentx.length);
		cent[CentCount].y   = getfloat(&linebuf[1],fcenty.from,fcenty.length);

		cent[CentCount].x = cent[CentCount].x / NetworkScale;
		cent[CentCount].y = cent[CentCount].y / NetworkScale;

		if(cent[CentCount].num == 0) {
			printf("\nerror: reading centroid data at line %d.\n", lines);
			exit(1);
			}
		}
	}

fclose(iptr);
}

/*************************************************************************/
void read_nodes(void)
{
int  lines;

NodeCount = lines=0;

if( (iptr = fopen(NodeFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",NodeFile);
	exit(1);
	}

while( (lines+1) < FirstNode) {
	fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

while( (fget_line(&linebuf[1],MAXSTR,iptr)) != EOF) {
	lines++;
	if(strlen(&linebuf[1]) > 5) {
		NodeCount++;
		if(NodeCount > NumNodes) {
			printf("\nerror: more than %d nodes found.\n", NumNodes);
			exit(1);
			}

		node[NodeCount].num = getlong(&linebuf[1],fnode.from,fnode.length);
		node[NodeCount].x   = getfloat(&linebuf[1],fnodex.from,fnodex.length);
		node[NodeCount].y   = getfloat(&linebuf[1],fnodey.from,fnodey.length);
		node[NodeCount].mindist
				= getfloat(&linebuf[1],fnodeu1.from,fnodeu1.length);
		node[NodeCount].maxdist
				= getfloat(&linebuf[1],fnodeu2.from,fnodeu2.length);

		node[NodeCount].x = node[NodeCount].x / NetworkScale;
		node[NodeCount].y = node[NodeCount].y / NetworkScale;

		if(node[NodeCount].num == 0) {
			printf("\nerror: reading node data at line %d.\n", lines);
			exit(1);
			}
		}
	}

fclose(iptr);
}

/*************************************************************************/
void drvlinks(void)
{
int    i, j;
int    BestNode, Printed;
double BestDist, X, Y;
double mindist, maxdist, dist;

/* create output file */
if( (optr = fopen(LinkFile,"w")) == NULL ) {
	printf("\nerror: opening file \"%s\" for writing.\n",LinkFile);
	exit(1);
	}

if(LinkFormat == 'e') {
	fprintf(optr,"c========================================\n");
	fprintf(optr,"c %s (TM)  Ver %s  Rel  %s\n", ProgName, VER, REL);
	fprintf(optr,"c========================================\n");
	fprintf(optr,"t links\n");
	}

/* set global search values */
mindist = MinDistance;
maxdist = MaxDistance;

/* loop through all the centroids and connect them to nodes */
LinkCount = 0;
printf("\nProcessing Zone:\n");

for (i=1; i <= CentCount; i++) {

	printf("%ld\r",cent[i].num);

	BestNode = 0;
	BestDist = 999999999;

	/* loop through nodes to find those within the search distance */
	for (j=1; j <= NodeCount; j++) {

	/* calculate distance */
	X = (double)((node[j].x - cent[i].x)*(node[j].x - cent[i].x));
	Y = (double)((node[j].y - cent[i].y)*(node[j].y - cent[i].y));

	switch(Distance) {
		case CARTESIAN : dist = sqrt(X + Y); break;
		case MANHATTEN : dist = X + Y;       break;
		default        : dist = sqrt(X + Y); break;
		}

	/* set search values */
	if(IndividualSearch > 0) {
		mindist = node[j].mindist;
		maxdist = node[j].maxdist;
		}

	/* write out link if node in search area */
	if( (dist >= mindist) && (dist <= maxdist) ) {
		if(MultipleLinks) {
			write_link(cent[i].num,node[j].num,dist);
			cent[i].connected += 1;
			node[j].connected += 1;
			}

		/* keep track of best node and write out later */
		else {
			if(dist < BestDist) {
				BestNode = j;
				BestDist = dist;
				}
			}
		} /* if dist */
	} /* for NodeCount */

	/* write out the best link to best node */
	if(! MultipleLinks) {
		if(BestNode != 0) {
			write_link(cent[i].num,node[BestNode].num,BestDist);
			cent[i].connected += 1;
			node[BestNode].connected += 1;
			}
		}
	} /* for CentCount */

printf("\n");
fprintf(rptr,"LINKS WRITTEN  = %d\n",LinkCount);

if(PrintUnconnected) {
	fprintf(rptr,"\nUNCONNECTED CENTROIDS\n");
	fprintf(rptr,  "----------------------\n\n");
	Printed = 0;
	for (i=1; i <= CentCount; i++) {
		if(cent[i].connected == 0) {
			fprintf(rptr," %6ld",cent[i].num);
			Printed++;
			if( Printed % 10 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

	fprintf(rptr,"\nUNCONNECTED NODES\n");
	fprintf(rptr,  "------------------\n\n");
	Printed = 0;
	for (i=1; i <= NodeCount; i++) {
		if(node[i].connected == 0) {
			fprintf(rptr," %6ld",node[i].num);
			Printed++;
			if( Printed % 10 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

	} /* if  PrintUnconnected */

if(PrintConnections) {
	fprintf(rptr,"\nNUMBER OF LINKS/CENTROID\n");
	fprintf(rptr,  "-------------------------\n\n");
	Printed = 0;
	for (i=1; i <= CentCount; i++) {
		if(cent[i].connected > 0) {
			fprintf(rptr," %6ld = %6ld |",cent[i].num,cent[i].connected);
			Printed++;
			if( Printed % 4 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

	fprintf(rptr,"\nNUMBER OF LINKS/NODE\n");
	fprintf(rptr,  "---------------------\n\n");
	Printed = 0;
	for (i=1; i <= NodeCount; i++) {
		if(node[i].connected > 0) {
			fprintf(rptr," %6ld = %6ld |",node[i].num,node[i].connected);
			Printed++;
			if( Printed % 4 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

	} /* if PrintConnections */

fclose(optr);
}

/*************************************************************************/
void usage(void)
{

run_header();

printf("\nSee written documentation for further details.\n");
printf("\nUSAGE:  %s  [control-file]\n", ProgName);
}

/*************************************************************************/
void  run_header()
{
int i;

for(i=1; i <= 20; i++)
	printf("\n");
printf("%s (TM) TRANSIT DRIVE LINK GENERATION PROGRAM\n",ProgName);
printf("Ver %s  Rel %s  (%s-Bit Version)\n", VER, REL, BIT);
for(i=1; i < 53; i++)
	printf("-");
printf("\n");
}

/*************************************************************************/
void  rpt_header()
{
int i;

fprintf(rptr,"%s (TM) TRANSIT DRIVE LINK GENERATION PROGRAM\n",ProgName);
fprintf(rptr,"Ver %s  Rel %s  (%s-Bit Version)\n", VER, REL, BIT);
for(i=1; i < 53; i++)
	fprintf(rptr,"-");
fprintf(rptr,"\n");
fflush(rptr);
}

/*************************************************************************/
void read_m2cents(void)
{
int  lines, endfile;

CentCount = lines=0;

if( (iptr = fopen(CentroidFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",CentroidFile);
	exit(1);
	}

/* skip "t" cards and blank lines - position pointer to read centroids */
do {
	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	} while ( (linebuf[2] != '*') && (endfile != EOF) );

if(endfile == EOF) {
	printf("\nerror: file \"%s\" ended suddenly.\n",CentroidFile);
	exit(1);
	}

/* start reading centroids */
while((linebuf[2] == '*') && (endfile != EOF) ) {
	if(linebuf[1] != 'a')
		break;
	CentCount++;
	if(CentCount > NumCentroids) {
		printf("\nerror: more than %d centroids found.\n", NumCentroids);
		exit(1);
		}

	if(sscanf(&linebuf[3]," %ld %f %f",
					&cent[CentCount].num,
					&cent[CentCount].x,
					&cent[CentCount].y) < 3) {
		printf("\nerror: in \"%s\" invalid file format, line %d\n",
					CentroidFile, lines);
		exit(1);
		}

	cent[CentCount].x = cent[CentCount].x / NetworkScale;
	cent[CentCount].y = cent[CentCount].y / NetworkScale;

	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

fclose(iptr);
}

/*************************************************************************/
void read_m2nodes(void)
{
int  lines, endfile;

NodeCount = lines=0;

if( (iptr = fopen(NodeFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",NodeFile);
	exit(1);
	}

/* skip "t" cards and blank lines - position pointer to read nodes */
do {
	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
   lines++;
   } while ( (linebuf[1] != 'a') && (endfile != EOF) );

if(endfile == EOF) {
	printf("\nerror: file \"%s\" ended suddenly.\n",NodeFile);
	exit(1);
	}

/* start reading nodes - first one has been read */
while( (endfile != EOF) && (linebuf[1] == 'a') ) {
	NodeCount++;
	if(NodeCount > NumNodes) {
		printf("\nerror: more than %d nodes found.\n", NumNodes);
		exit(1);
		}

	if(sscanf(&linebuf[3]," %ld %f %f %f %f",
		&node[NodeCount].num,
		&node[NodeCount].x,
		&node[NodeCount].y,
		&node[NodeCount].mindist,
		&node[NodeCount].maxdist) < 3) {
		printf("\nerror: in \"%s\" invalid file format, line %d\n",
			NodeFile,lines);
		exit(1);
		}

	node[NodeCount].x = node[NodeCount].x / NetworkScale;
	node[NodeCount].y = node[NodeCount].y / NetworkScale;

	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

fclose(iptr);
}

/*************************************************************************/
void pick_frto(char *tempbuf, int *from, int *to, int *length)
{
int err = FALSE;

if( (sscanf(tempbuf," %d - %d", from, to)) < 2)
  err = TRUE;
if(*to < *from)
  err = TRUE;
if( (*from <= 0) || (*to <= 0) )
  err = TRUE;

*length = (*to - *from) + 1;

if(err) {
	printf("\nerror: reading line:\n=>%s", tempbuf);
	exit(1);
	}

}

/*************************************************************************/
void write_link(long cent, long cnode, float dist)
{
char FormatString[MAXSTR];
long ldist, ltime;
float fdist;

if(LinkFormat == 'e') {
	if(DeleteLinks) {

		sprintf(FormatString,"d %%ld,%%ld\n");
		switch(newlink.direction) {
			case 't':
				fprintf(optr,FormatString,cent,cnode);
				fprintf(optr,FormatString,cnode,cent);
				break;
			case 'i':
				fprintf(optr,FormatString,cnode,cent);
				break;
			case 'o':
				fprintf(optr,FormatString,cent,cnode);
				break;
			}
		} /* DeleteLinks */

	sprintf(FormatString,"a %%ld,%%ld,%%.4f,%%s,%%d,%%.1f,%%d,0,0,0\n");

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,dist,newlink.modesout,newlink.type,
				newlink.lanes,newlink.vdf);
				LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,dist,newlink.modesin,newlink.type,
				newlink.lanes,newlink.vdf);
			 LinkCount++;
			 break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,dist,newlink.modesin,newlink.type,
				newlink.lanes,newlink.vdf);
			LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,dist,newlink.modesout,newlink.type,
				newlink.lanes,newlink.vdf);
			LinkCount++;
			break;
		}

	} /* if LinkFormat == e */
else
if(LinkFormat == 't') {
	sprintf(FormatString,"1%%5ld%%5ld %%-2s        %%4ld   %%3ld   %%3ld   %%3ld1\n");

	ldist = dist*10;
	ltime = (dist/DriveSpeed)*60*10;

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,ldist,ltime,ltime,ltime);
				LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,ldist,ltime,ltime,ltime);
				LinkCount++;
			 LinkCount++;
			 break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,ldist,ltime,ltime,ltime);
				LinkCount++;
			 LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,ldist,ltime,ltime,ltime);
				LinkCount++;
			break;
		}

	} /* if LinkFormat == t */
else
if(LinkFormat == 'i') {

	sprintf(FormatString,"1%%5ld%%5ld %%-2s         %%.2f %%4.1f            1\n");

	fdist = dist;

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,fdist,DriveSpeed);
			LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,fdist,DriveSpeed);
			LinkCount++;
			break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,fdist,DriveSpeed);
			LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,fdist,DriveSpeed);
			LinkCount++;
			break;
		}

	} /* if LinkFormat == i */

}

/* sample emme/2 link record */
/*a      1   9020   1.17 p             61 0.0   0     150  91.023   97.65 */


