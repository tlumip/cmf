/*
 * WLKLINKS.C
 * written by   :  Tim Heier
 * last updated :  07/20/97
 */

#define VER          "2.20"
#define REL      " 7/20/97"
#define BIT            "32"

char *ProgName = "WLKLINKS";

/*
The basic program logic goes like this:

1. Start from a centroid and find all the nodes within the search values.
2. The canidate transit nodes are then sorted by distance from centroid.
3. The canidate node closest to centroid is accepted into final node set.
4. Subsequent nodes are accepted into the final node set if one or more
	transit lines passing through the node did not pass through the
	previous nodes in the final set.
5. The previous logic can be turned off so nodes are accepted based only
	on distance.
*/

#include <stdutil.h>
#include <ctlutil.h>

#define MAXSTR         120
#define MAXROUTES     1500
#define MAXDIR           2
#define MAXCANIDATES    99
#define CARTESIAN        0
#define MANHATTEN        1

typedef struct {
	float  mindist;
	float  maxdist;
	float  avgdist;
	long   connect;
	long   cNodes;
} stat_data;

typedef struct {
	long   num;
	float  x;
	float  y;
	long   connected;
	float  mindist;
	float  maxdist;
	float  maxlinks;
} cent_data;

typedef struct {
	long   num;
	float  x;
	float  y;
	long   connected;
	float  canidate;
	float  distance;
} node_data;

typedef struct {
	int    type;
	int    vdf;
	char   modesin[MAXSTR];
	char   modesout[MAXSTR];
	char   direction;
	float  lanes;
} link_data;

typedef struct {
	int    from;
	int    to;
	int    length;
} col_data;

struct cdata {
	long	node;
	float	dist;
};

struct RouteList {
	int   Dir;
	long	Node;
	float	Dwell;
	struct RouteList *next;
};

struct LineDesc {
	char	Line[7];
	char  Desc[MAXSTR];
	char  cMode;
	int	iMode, VehTyp, RG, Dir[MAXDIR+1];
	float	TF, D, S, T, H1, H2, H3;
	float	td1,td2,td3;
	struct RouteList *Route;
};

/* user defined data */
struct LineDesc *TrLine[MAXROUTES];
stat_data  *stat;
cent_data  *cent;
node_data  *node;
link_data  newlink;

col_data   fnode, fnodex, fnodey;
col_data   fcent, fcentx, fcenty, fcentu1, fcentu2, fcentu3;

/* global variables */
FILE  *iptr, *rptr, *optr, *aptr;
int   CentCount, NodeCount, NumRoutes, LinkCount;
char  *linebuf;
char  *iniFile, *CentroidFile, *NodeFile, *TransitFile;
char  *LinkFile, *ReportFile, *AccessFile;

int   NumCentroids,MaxLinks,SelectModes;
long  HiNodeNumber;
float NetworkScale,MinDistance,MaxDistance,WalkSpeed;
char  SearchModes[MAXSTR];

int   PrintUnconnected,PrintConnections,PrintStats,DryRun,Debug;
int   Distance,AverageDistance,IndividualSearch,IndividualMax;
int   FirstCentroid,FirstNode,EchoTransitLines,LinesAccessed;

int   DeleteLinks,MultipleStops,SplitLines,PrintLines;
char  NodeFormat,CentroidFormat,TransitFormat,LinkFormat;
char  PrintLine[7];

void  read_ini(void);
void  read_cents(void);
void  read_m2cents(void);
void  read_nodes(void);
void  read_m2nodes(void);
void  read_m2lines(void);
void  read_tplines(void);
void  echo_transit(void);
void  wlklinks(void);
void  write_link(long cent, long cnode, float dist);
void  usage(void);
void  run_header(void);
void  rpt_header(FILE *ptr);
void  pick_frto(char *tempbuf, int *from, int *to, int *length);
void  add_to_route (struct RouteList *, struct RouteList *);
void  sorts(float *,float *, int, int);
int   sort_function( const void *a, const void *b);

int main(int argc, char* argv[])
{

if(argc < 2) {
	usage();
	exit(1);
	}

/* allocate memory for strings */
CentroidFile = (char *) malloc(MAXSTR);
NodeFile     = (char *) malloc(MAXSTR);
TransitFile  = (char *) malloc(MAXSTR);
LinkFile     = (char *) malloc(MAXSTR);
ReportFile   = (char *) malloc(MAXSTR);
AccessFile   = (char *) malloc(MAXSTR);
iniFile      = (char *) malloc(MAXSTR);
linebuf      = (char *) malloc(MAXSTR);

/* allocate memory for character arrays */
if( (CentroidFile == NULL) || (NodeFile == NULL) || (LinkFile == NULL) ||
	 (ReportFile == NULL)   || (iniFile == NULL)  || (linebuf == NULL)  ||
	 (TransitFile == NULL)  || (AccessFile == NULL) ) {
	printf("\nerror: not enough memory to allocate string buffers\n");
	exit(1);
	}

strcpy(iniFile,argv[1]);

run_header();

read_ini();

if(DryRun)
	exit(1);

/* allocate memory for data */
if( (cent = calloc( NumCentroids+1, sizeof(cent_data))) == NULL ) {
	printf("\nerror: allocating centroid buffer\n");
	exit(1);
	}
if( (stat = calloc( NumCentroids+1, sizeof(stat_data))) == NULL ) {
	printf("\nerror: allocating stats buffer\n");
	exit(1);
	}
if( (node = calloc( HiNodeNumber+1, sizeof(node_data))) == NULL ) {
	printf("\nerror: allocating node buffer\n");
	exit(1);
	}

switch(CentroidFormat) {
	case 'e': read_m2cents(); break;
	default : read_cents();   break;
	}

switch(NodeFormat) {
	case 'e': read_m2nodes(); break;
	default : read_nodes();   break;
	}

switch(TransitFormat) {
	case 'e': read_m2lines(); break;
	case 't': read_tplines(); break;
	}

if(EchoTransitLines)
	echo_transit();

fprintf(rptr,"\nRUN RESULTS\n");
fprintf(rptr,  "------------\n\n");
fprintf(rptr,"CENTROIDS READ = %d\n",CentCount);
fprintf(rptr,"NODES READ     = %d\n",NodeCount);

wlklinks();

return(0);
}

/*************************************************************************/
void read_ini(void)
{
char i,j,k,c, tempbuf[MAXSTR];

/* FILES Section */
strcpy(linebuf,"Files");
GetPrivateProfileString(linebuf,"CentroidFile","cents.in",
			CentroidFile, iniFile);
GetPrivateProfileString(linebuf,"NodeFile","nodes.in",
			NodeFile, iniFile);
GetPrivateProfileString(linebuf,"TransitFile","lines.in",
			TransitFile, iniFile);
GetPrivateProfileString(linebuf,"LinkFile","wlklinks.out",
			LinkFile, iniFile);
GetPrivateProfileString(linebuf,"ReportFile","wlklinks.rpt",
			ReportFile, iniFile);
GetPrivateProfileString(linebuf,"AccessFile","access.rpt",
			AccessFile, iniFile);

/* open report file */
if( (rptr = fopen(ReportFile,"w")) == NULL ) {
	printf("\nerror: opening file \"%s\" for writing.", ReportFile);
	exit(1);
	}
rpt_header(rptr);

/* open control file */
if( (iptr = fopen(iniFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.", iniFile);
	exit(1);
	}

/* echo control file to report file */
fprintf(rptr,"\nCONTROL FILE\n");
fprintf(rptr,  "-------------\n\n");
while( (c = getc(iptr) ) != EOF)
	putc(c, rptr);
fclose(iptr);

/* PARAMETERS Section */
strcpy(linebuf,"Parameters");
DryRun =
	GetPrivateProfileBool(linebuf,"DryRun",0,iniFile);
NumCentroids =
	GetPrivateProfileInt(linebuf,"NumCentroids",2000,iniFile);
GetPrivateProfileString(linebuf,"HiNodeNumber","10000",tempbuf,iniFile);
HiNodeNumber = atol(tempbuf);
MaxLinks =
	GetPrivateProfileInt(linebuf,"MaxLinks",4,iniFile);
MinDistance =
	GetPrivateProfileFloat(linebuf,"MinDistance",0.0,iniFile);
MaxDistance =
	GetPrivateProfileFloat(linebuf,"MaxDistance",0.333,iniFile);
NetworkScale =
	GetPrivateProfileFloat(linebuf,"NetworkScale",1.0,iniFile);
SelectModes =
	GetPrivateProfileBool(linebuf,"SelectModes",0,iniFile);
GetPrivateProfileString(linebuf,"SearchModes","b",SearchModes,iniFile);
WalkSpeed =
	GetPrivateProfileFloat(linebuf,"WalkSpeed",3.0,iniFile);
GetPrivateProfileString(linebuf,"Distance","cartesian",
			tempbuf, iniFile);
if(toupper(tempbuf[0]) == 'C')
	Distance = CARTESIAN;
else
	Distance = MANHATTEN;

AverageDistance =
	GetPrivateProfileBool(linebuf,"AverageDistance",1,iniFile);
IndividualSearch =
	GetPrivateProfileBool(linebuf,"IndividualSearch",0,iniFile);
IndividualMax =
	GetPrivateProfileBool(linebuf,"IndividualMax",0,iniFile);
MultipleStops =
	GetPrivateProfileBool(linebuf,"MultipleStops",0,iniFile);
SplitLines =
	GetPrivateProfileBool(linebuf,"SplitLines",0,iniFile);

if(NumCentroids == 0) {
	printf("\nerror: number of centroids cannot be zero.\n");
	exit(1);
	}
if(HiNodeNumber <=  0) {
	printf("\nerror: number of nodes cannot be zero.\n");
	exit(1);
	}
if(NetworkScale <= 0) {
	printf("\nerror: network scale must be a positive value.\n");
	exit(1);
	}
if(MaxDistance < MinDistance) {
	printf("\nerror: maximum distance cannot be less than minimum.\n");
	exit(1);
	}
if((MaxLinks <= 0) || (MaxLinks > MAXCANIDATES)) {
	printf("\nerror: maximum links is out of range.\n");
	exit(1);
	}
if(WalkSpeed <= 0) {
	printf("\nerror: walk speed must be a positive value.\n");
	exit(1);
	}

/* REPORTS Section */
strcpy(linebuf,"Reports");

EchoTransitLines =
	GetPrivateProfileBool(linebuf,"EchoTransitLines",1,iniFile);
PrintStats =
	GetPrivateProfileBool(linebuf,"PrintStats",1,iniFile);
PrintUnconnected =
	GetPrivateProfileBool(linebuf,"PrintUnconnected",1,iniFile);
PrintConnections =
	GetPrivateProfileBool(linebuf,"PrintConnections",1,iniFile);
LinesAccessed =
	GetPrivateProfileBool(linebuf,"LinesAccessed",0,iniFile);

/* these are undocumented options */
Debug =
	GetPrivateProfileBool(linebuf,"Debug",0,iniFile);
GetPrivateProfileString(linebuf,"PrintLine","\0",
			PrintLine, iniFile);
PrintLines =
	GetPrivateProfileBool(linebuf,"PrintLines",0,iniFile);

/* pad the line id with blanks */
if(strlen(PrintLine) > 0) {
	i=strlen(PrintLine);
	j=6;
	for(k=i; k < j; k++)
		PrintLine[k] = ' ';
	PrintLine[j] = '\0';
	}

/* CENTROID FORMAT Section */
strcpy(linebuf,"Centroid Format");
GetPrivateProfileString(linebuf,"CentroidFormat","u",
			tempbuf, iniFile);
CentroidFormat = tolower(tempbuf[0]);
if( (CentroidFormat != 'u') && (CentroidFormat != 'e') ) {
	printf("\nerror: invalid *CentroidFormat* entry = %c\n",CentroidFormat);
	exit(1);
	}

if(CentroidFormat == 'u') {
	GetPrivateProfileString(linebuf,"Number","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcent.from, &fcent.to, &fcent.length);

	GetPrivateProfileString(linebuf,"XCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcentx.from, &fcentx.to, &fcentx.length);

	GetPrivateProfileString(linebuf,"YCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fcenty.from, &fcenty.to, &fcenty.length);

   if (IndividualSearch) {
		GetPrivateProfileString(linebuf,"User1","\0",
			tempbuf, iniFile);
		pick_frto(tempbuf, &fcentu1.from, &fcentu1.to, &fcentu1.length);
		GetPrivateProfileString(linebuf,"User2","\0",
			tempbuf, iniFile);
		pick_frto(tempbuf, &fcentu2.from, &fcentu2.to, &fcentu2.length);
   	}

   if (IndividualMax) {
		GetPrivateProfileString(linebuf,"User3","\0",
			tempbuf, iniFile);
		pick_frto(tempbuf, &fcentu3.from, &fcentu3.to, &fcentu3.length);
   	}

	FirstCentroid = GetPrivateProfileInt(linebuf,"FirstCentroid",1,iniFile);
	}

/* NODE FORMAT Section */
strcpy(linebuf,"Node Format");
GetPrivateProfileString(linebuf,"NodeFormat","u",
			tempbuf, iniFile);
NodeFormat = tolower(tempbuf[0]);
if( (NodeFormat != 'u') && (NodeFormat != 'e') ) {
	printf("\nerror: invalid *NodeFormat* entry = %c\n",NodeFormat);
	exit(1);
	}

if(NodeFormat == 'u') {
	GetPrivateProfileString(linebuf,"Number","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnode.from, &fnode.to, &fnode.length);
	GetPrivateProfileString(linebuf,"XCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodex.from, &fnodex.to, &fnodex.length);
	GetPrivateProfileString(linebuf,"YCoord","\0",
			tempbuf, iniFile);
	pick_frto(tempbuf, &fnodey.from, &fnodey.to, &fnodey.length);
	FirstNode = GetPrivateProfileInt(linebuf,"FirstNode",1,iniFile);
	}

/* TRANSIT FORMAT Section */
strcpy(linebuf,"Transit Format");
GetPrivateProfileString(linebuf,"TransitFormat","e",
			tempbuf, iniFile);
TransitFormat = tolower(tempbuf[0]);
if( (TransitFormat != 'e') && (TransitFormat != 't') ) {
	printf("\nerror: invalid *TransitFormat* entry = %c\n",TransitFormat);
	exit(1);
	}

/* NEW LINK ATTRIBUTES Section */
strcpy(linebuf,"New Link Attributes");
DeleteLinks =
	GetPrivateProfileBool(linebuf,"DeleteLinks",0,iniFile);
newlink.lanes =
	GetPrivateProfileFloat(linebuf,"Lanes",1.0,iniFile);
newlink.type =
	GetPrivateProfileInt(linebuf,"LinkType",99,iniFile);
newlink.vdf =
	GetPrivateProfileInt(linebuf,"VolumeDelay",99,iniFile);
GetPrivateProfileString(linebuf,"ModesIn","i",
	newlink.modesin, iniFile);
GetPrivateProfileString(linebuf,"ModesOut","o",
	newlink.modesout, iniFile);
GetPrivateProfileString(linebuf,"LinkFormat","e",
			tempbuf, iniFile);
LinkFormat = tolower(tempbuf[0]);
if( (LinkFormat != 'e') && (LinkFormat != 't') && (LinkFormat != 'i') ) {
	printf("\nerror: invalid *LinkFormat* entry = %s\n",tempbuf);
	exit(1);
	}
GetPrivateProfileString(linebuf,"Direction","twoway",
	tempbuf, iniFile);
newlink.direction = tolower(tempbuf[0]);
if( (newlink.direction != 't') && (newlink.direction != 'i') &&
		(newlink.direction != 'o') ) {
	printf("\nerror: invalid *Direction* entry = %s\n",tempbuf);
	exit(1);
	}

if(TransitFormat == 't') {
	SplitLines = FALSE;
	}
if( (LinkFormat == 't') || (LinkFormat == 'i') ) {
	DeleteLinks = FALSE;
	}
}

/*************************************************************************/
void echo_transit(void)
{
int i, j, Printed;
struct RouteList *Chain;

fprintf(rptr,"\nTRANSIT LINES READ = %4d\n", NumRoutes);
fprintf(rptr,  "--------------------------\n\n");
Printed = 0;

for(j=1; j <= NumRoutes; j++) {
	if(TrLine[j] != NULL) {
		fprintf(rptr,"   %6s",TrLine[j]->Line);
		Printed++;
		if( Printed % 8 == 0)
			fprintf(rptr,"\n");
		}
	}

fprintf(rptr,"\n");

if(strlen(PrintLine) > 0) {
	fprintf(rptr,"\nPRINT LINE = %6s\n", PrintLine);
	fprintf(rptr,  "--------------------\n\n");
	for (i=1; i < MAXROUTES; i++) {
		if (TrLine[i] != NULL) {
			if (strncmp (TrLine[i]->Line, PrintLine,strlen(TrLine[i]->Line)) == 0) {
				 fprintf(rptr,  "Description = %s\n",TrLine[i]->Desc);
				 if(TransitFormat == 'e')
					fprintf(rptr,  "Mode = %c\n",TrLine[i]->cMode);
				 else
				 if(TransitFormat == 't')
					fprintf(rptr,  "Mode = %d\n",TrLine[i]->iMode);

				 Chain = TrLine[i]->Route;
				 j=0;
				 while (Chain != NULL) {
					if (j++ % 8 == 0)
						fprintf(rptr,"\n");
					fprintf(rptr,"%8ld", Chain->Node);
					Chain = Chain->next;
					}
				fprintf(rptr,"\n");
				break;
				}
			}
		}
	}

if(PrintLines) {
	for (i=1; i < MAXROUTES; i++) {
		if (TrLine[i] != NULL) {
			fprintf(rptr,  "\nDescription = %s\n",TrLine[i]->Desc);
			if(TransitFormat == 'e')
				fprintf(rptr,  "Mode = %c\n",TrLine[i]->cMode);
			else
				if(TransitFormat == 't')
					fprintf(rptr,  "Mode = %d\n",TrLine[i]->iMode);

			Chain = TrLine[i]->Route;
			j=0;
			while (Chain != NULL) {
				if (j++ % 8 == 0)
					fprintf(rptr,"\n");
				fprintf(rptr,"%8ld", Chain->Node);
				Chain = Chain->next;
				}

			fprintf(rptr,"\n");
			}
		}
	}
}

/*************************************************************************/
void wlklinks(void)
{
int    i,j,k,m;
int    cNodes, fNodes, CurDir;
int    Printed, UseNode, UseLine, maxlinks;
char   mstring[MAXSTR];
long   l, tnode;
double X, Y, Arg, sumdist, nitems;
double mindist, maxdist, dist;
struct RouteList *Chain;
struct cdata *canidate;

/* allocate memory for canidate array */
if( (canidate = calloc( MAXCANIDATES+1, sizeof(struct cdata))) == NULL ) {
	printf("\nerror: allocating canidate node buffer\n");
	exit(1);
	}

/* create output file */
if( (optr = fopen(LinkFile,"w")) == NULL ) {
	printf("\nerror: opening file \"%s\" for writing.\n",LinkFile);
	exit(1);
	}

if(LinkFormat == 'e') {
	fprintf(optr,"c========================================\n");
	fprintf(optr,"c %s (TM)  Ver %s  Rel  %s\n", ProgName, VER, REL);
	fprintf(optr,"c========================================\n");
	fprintf(optr,"t links\n");
	}

if(LinesAccessed) {
	if( (aptr = fopen(AccessFile,"w")) == NULL ) {
		printf("\nerror: opening file \"%s\" for writing.\n",AccessFile);
		exit(1);
		}
	rpt_header(aptr);
	fprintf(aptr,"\n");
	}

/* get global search values */
mindist  = MinDistance;
maxdist  = MaxDistance;
maxlinks = MaxLinks;

/* loop through all the centroids and connect them to nodes */
LinkCount = 0;

printf("\nProcessing Zone:\n");

for (i=1; i <= CentCount; i++) {
	printf("%ld\r",cent[i].num);

	if(Debug) {
		fprintf(rptr,"\nCentroid=%d\n",i);
		if(IndividualSearch) {
			fprintf(rptr,"Min Dist=%.3f\n",cent[i].mindist);
			fprintf(rptr,"Max Dist=%.3f\n",cent[i].maxdist);
			}
		if(IndividualMax)
			fprintf(rptr,"Max Links=%.3f\n",cent[i].maxlinks);
		}

	/* clear canidate arrays */
	for (l=1; l <= HiNodeNumber; l++) {
		node[l].canidate = 0;
		node[l].distance = 0;
		}
	for(k=0; k <= MAXCANIDATES; k++) {
		canidate[k].node = 0;
		canidate[k].dist = 0;
		}

	/* set search values based on current centroid */
	if(IndividualSearch) {
		mindist = cent[i].mindist;
		maxdist = cent[i].maxdist;
		}

	if(IndividualMax)
		maxlinks = cent[i].maxlinks;

	/* loop through nodes in transit lines to find those
		within the search distance */
	for(j=1; j <= NumRoutes; j++) {
		if(TrLine[j] != NULL) {

			UseLine = TRUE;
			if(SelectModes) {
				switch (TransitFormat) {
					case 'e':
						mstring[0] = TrLine[j]->cMode;
						mstring[1] = '\0';
						break;
					case 't':
						sprintf(mstring,"%d",TrLine[j]->iMode);
						break;
					}
				if(str_index(SearchModes,mstring) < 0)
					UseLine = FALSE;
				}

			 if(UseLine) {
				Chain = TrLine[j]->Route;
				while(Chain != NULL) {
					if(Chain->Node < 0) {
						tnode = labs(Chain->Node);

						if(tnode > HiNodeNumber) {
							fprintf(rptr,"error: transit stop %ld is greater than highest node number\n",
								tnode);
							exit(1);
							}

						/* calculate distance */
						switch(Distance) {
							case CARTESIAN :
								X=(double)((node[tnode].x-cent[i].x)*(node[tnode].x-cent[i].x));
								Y=(double)((node[tnode].y-cent[i].y)*(node[tnode].y-cent[i].y));
								Arg = X + Y;
								if(Arg <= 0) {
									fprintf(rptr,"warning: invalide distance for centroid = %ld, node = %ld\n",
										cent[i].num, node[tnode].num);
									}
								dist = sqrt(Arg);
								break;
							case MANHATTEN :
								X=(double)fabs((node[tnode].x-cent[i].x));
								Y=(double)fabs((node[tnode].y-cent[i].y));
								dist = X + Y;
								break;
							}

						/* mark node if in search distance */
						if( (dist >= mindist) && (dist <= maxdist) ) {
							node[tnode].canidate++;
							node[tnode].distance = dist;
							}
						} /* Chain->Node < 0 */

					Chain = Chain->next;

					} /* chain != null */
				} /* if UseLine */
			} /* Trline != null */
		} /* for j */

	/* build canidate array based on markers */
	cNodes = 0;
	for (l=1; l <= HiNodeNumber; l++) {
		if(node[l].canidate > 0) {
			cNodes++;
			if(cNodes > MAXCANIDATES) {
				cNodes = MAXCANIDATES;
				break;;
				}
			canidate[cNodes].node = (float)node[l].num;
			canidate[cNodes].dist = (float)node[l].distance;
			} /* if > 0 */
		} /* for l */

	if(Debug) {
		if(cNodes > 0) {
			fprintf(rptr,"Nodes=%d\nbefore sort...\n",cNodes);
			for (j=1; j <= cNodes; j++)
				fprintf(rptr,"%2d.  num=%6ld  dist=%7.3f\n",
					j,canidate[j].node,canidate[j].dist);
			}
		}

	/* sort canidate nodes by distance */
	qsort((void *)&canidate[1], cNodes, sizeof(struct cdata), sort_function);

	if(Debug) {
		if(cNodes > 0) {
			fprintf(rptr,"after sort...\n");
			for(j=1; j <= cNodes; j++)
				fprintf(rptr,"%2d.  num=%6ld  dist=%7.3f\n",
					j,canidate[j].node,canidate[j].dist);
			}
		}

	/* clear "used" flag before checking canidate nodes */
	for(j=1; j <= NumRoutes; j++)
		for(k=0; k <= MAXDIR; k++)
			TrLine[j]->Dir[k] = 0;

	if(Debug) {
		if(cNodes > 0)
			fprintf(rptr,"during line check...\n");
		}

	/* loop through canidates nodes, figure out which ones makes it */
	fNodes = 0;
	for(k=1; k <= cNodes; k++) {

		UseNode = 0;
		if(fNodes < maxlinks) {

			/* loop through transit nodes and mark connected lines */
			if(! MultipleStops) {
				for(j=1; j <= NumRoutes; j++) {
					if(TrLine[j] != NULL) {
						Chain = TrLine[j]->Route;
						while(Chain != NULL) {
							tnode = labs(Chain->Node);
							if(tnode == canidate[k].node) {
								if(SplitLines) {
									CurDir = Chain->Dir;
									if(TrLine[j]->Dir[CurDir] == 0) {
										TrLine[j]->Dir[CurDir] = 1;
										UseNode++;
										}
									}
								else {
									if(TrLine[j]->Dir[0] == 0) {
										TrLine[j]->Dir[0] = 1;
										UseNode++;
										}
									}
								}

							Chain = Chain->next;

							} /* chain != null */
						} /* Trline != null */
					} /* for j */
				} /* if ! MultipleStops */
			else {
				UseNode++;
				}

			if(Debug)
				fprintf(rptr,"node=%6ld  new lines=%3d\n",canidate[k].node,UseNode);

			} /* if fNodes <= maxlinks */

		if(UseNode > 0)
			fNodes++;
		else
			canidate[k].node = 0;

		NEXTNODE: ;
		} /* for cNodes */

	if(Debug) {
		if(fNodes > 0) {
			fprintf(rptr,"after line check...\n");
			for(j=1; j <= cNodes; j++)
				if(canidate[j].node > 0)
					fprintf(rptr,"%2d.  num=%6ld  dist=%7.3f\n",
						j,canidate[j].node,canidate[j].dist);
			}
		}

	/* calculate statistics for each centroid */
	sumdist = nitems = 0;
	if(fNodes > 0) {
		stat[i].mindist = 99999999;
		stat[i].maxdist = 0;
		stat[i].cNodes = cNodes;
		for(j=1; j <= cNodes; j++) {
			if(canidate[j].node > 0) {
				sumdist += canidate[j].dist;
				nitems++;
				if(canidate[j].dist < stat[i].mindist)
					stat[i].mindist = canidate[j].dist;
				if(canidate[j].dist > stat[i].maxdist)
					stat[i].maxdist = canidate[j].dist;
				}
			}
		if(nitems == 0) {
			stat[i].mindist = 0;
			stat[i].maxdist = 0;
			stat[i].avgdist = 0;
			stat[i].connect = 0;
			}
		else {
			stat[i].avgdist = sumdist / nitems;
			stat[i].connect = nitems;
			}

		} /* if fNodes */

	/* calculate average distance for all links */
	sumdist = nitems = 0;
	if( (AverageDistance) && (fNodes > 0) ) {
		for(j=1; j <= cNodes; j++) {
			if(canidate[j].node > 0) {
				sumdist += canidate[j].dist;
				nitems++;
				}
			}
		if(nitems == 0) {
			fprintf(rptr,"warning: average connector distance is zero for centroid = %ld\n",
				cent[i].num);
			dist = MaxDistance;
			}
		else
			dist = sumdist / nitems;

		/* assign average distance to each node */
		for(j=1; j <= cNodes; j++) {
			if(canidate[j].node > 0)
				canidate[j].dist = (float)dist;
			}

		} /* if AverageDistance */

	/* write out links to final nodes */
	if(fNodes > 0)
		for(j=1; j <= cNodes; j++)
			if(canidate[j].node > 0) {
				write_link(cent[i].num,canidate[j].node,canidate[j].dist);
				cent[i].connected += 1;
				node[canidate[j].node].connected += 1;
				}

	if(LinesAccessed) {
		fprintf(aptr,"Centroid = %ld\n",cent[i].num);
		for(j=1; j < NumRoutes; j++) {
			if(TrLine[j] != NULL) {
				m = 0;
				for(k=0; k <= MAXDIR; k++)
					m += TrLine[j]->Dir[k];
				if(m > 0)
					fprintf(aptr," %6s\n",TrLine[j]->Line);
				}
			}
		}


	} /* for CentCount */

printf("\n");
fprintf(rptr,"LINKS WRITTEN  = %d\n",LinkCount);

if(PrintUnconnected) {
	fprintf(rptr,"\nUNCONNECTED CENTROIDS\n");
	fprintf(rptr,  "----------------------\n\n");
	Printed = 0;
	for (i=1; i <= CentCount; i++) {
		if(! cent[i].connected) {
			fprintf(rptr," %6ld",cent[i].num);
			Printed++;
			if( Printed % 10 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

	} /* if  PrintUnconnected */

if(PrintConnections) {
	fprintf(rptr,"\nNUMBER OF TWO-WAY LINKS/CENTROID\n");
	fprintf(rptr,  "---------------------------------\n\n");
	Printed = 0;
	for (i=1; i <= CentCount; i++) {
		if(cent[i].connected > 0) {
			fprintf(rptr," %6ld = %6ld |",cent[i].num,cent[i].connected);
			Printed++;
			if( Printed % 4 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");

/* this code works but it could be a long output
	fprintf(rptr,"\nNUMBER OF TWO-WAY LINKS/NODE\n");
	fprintf(rptr,  "-----------------------------\n\n");
	Printed = 0;
	for (i=1; i <= HiNodeNumber; i++) {
		if(node[i].connected > 0) {
			fprintf(rptr," %6ld = %6ld |",node[i].num,node[i].connected);
			Printed++;
			if( Printed % 4 == 0)
				fprintf(rptr,"\n");
			}
		}
	fprintf(rptr,"\n");
*/
	} /* if PrintConnections */

if(PrintStats) {
	fprintf(rptr,"\nCENTROID CONNECTION STATISTICS\n");
	fprintf(rptr,  "-------------------------------\n\n");
	fprintf(rptr,"            Canidate     Final       min       max       avg\n");
	fprintf(rptr,"Centroid       links     links      dist      dist      dist\n");
	fprintf(rptr,"--------------------------------------------------------------\n");
	for (i=1; i <= CentCount; i++) {
		fprintf(rptr,"%8ld  = %8ld %9ld  %8.3f  %8.3f  %8.3f\n",cent[i].num,
			stat[i].cNodes, stat[i].connect,stat[i].mindist, stat[i].maxdist,
			stat[i].avgdist);
		}

	} /* if  PrintStats */

fclose(optr);
fclose(aptr);
}

/*************************************************************************/
int sort_function( const void *a, const void *b)
{
struct cdata *i, *j;

i = (struct cdata *)a;
j = (struct cdata *)b;

if(i->dist < j->dist)
	return -1;
else
if(i->dist == j->dist)
	return 0;
if(i->dist > j->dist)
	return 1;

return 0;
}

/*************************************************************************/
void add_to_route (struct RouteList *a, struct RouteList *b)
{
	if (a->next == NULL)
		a->next = b;
	else
		add_to_route (a->next, b);
}

/*************************************************************************/
void read_cents(void)
{
int  lines;

CentCount = lines = 0;

if( (iptr = fopen(CentroidFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",CentroidFile);
	exit(1);
	}

while( (lines+1) < FirstCentroid) {
	fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

while( (fget_line(&linebuf[1],MAXSTR,iptr)) != EOF) {
	lines++;
	if(strlen(&linebuf[1]) > 5) {
		CentCount++;
		if(CentCount > NumCentroids) {
			printf("\nerror: more than %d centroids found.\n", NumCentroids);
			exit(1);
			}

		cent[CentCount].num = getlong(&linebuf[1],fcent.from,fcent.length);
		cent[CentCount].x   = getfloat(&linebuf[1],fcentx.from,fcentx.length);
		cent[CentCount].y   = getfloat(&linebuf[1],fcenty.from,fcenty.length);

		cent[CentCount].mindist
				= getfloat(&linebuf[1],fcentu1.from,fcentu1.length);
		cent[CentCount].maxdist
				= getfloat(&linebuf[1],fcentu2.from,fcentu2.length);
		cent[CentCount].maxlinks
				= getfloat(&linebuf[1],fcentu3.from,fcentu3.length);

		cent[CentCount].x = cent[CentCount].x / NetworkScale;
		cent[CentCount].y = cent[CentCount].y / NetworkScale;

		if(cent[CentCount].num == 0) {
			printf("\nerror: reading centroid data at line %d.\n", lines);
			exit(1);
			}
		}
	}

fclose(iptr);
}

/*************************************************************************/
void read_nodes(void)
{
int  lines;
long n;

NodeCount = lines = 0;

if( (iptr = fopen(NodeFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",NodeFile);
	exit(1);
	}

while( (lines+1) < FirstNode) {
	fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

while( (fget_line(&linebuf[1],MAXSTR,iptr)) != EOF) {
	lines++;
	if(strlen(&linebuf[1]) > 5) {
		NodeCount++;
		n = getlong(&linebuf[1],fnode.from,fnode.length);

		if(n > HiNodeNumber) {
			printf("\nerror: node number higher than %d found.\n", HiNodeNumber);
			exit(1);
			}

		node[n].num = n;
		node[n].x   = getfloat(&linebuf[1],fnodex.from,fnodex.length);
		node[n].y   = getfloat(&linebuf[1],fnodey.from,fnodey.length);

		node[n].x = node[n].x / NetworkScale;
		node[n].y = node[n].y / NetworkScale;

		if(node[n].num == 0) {
			printf("\nerror: reading node data at line %d.\n", lines);
			exit(1);
			}
		}
	}

fclose(iptr);
}

/*************************************************************************/
void read_m2lines (void)
{
char InputString[MAXSTR];
char Value[15], special;
long RealNode;
float dwell;
int FoundNodes, Stop, CurDir;
int i, c1, c2, slen;
struct RouteList *Chain;
struct LineDesc  *TransitLine;
FILE *fp;

NumRoutes = 0;

/* Open the Transit Line file for reading */
if ((fp = fopen(TransitFile, "r")) == NULL) {
	printf("\nerror: opening file \"%s\" for reading.\n",TransitFile);
	exit(1);
	}

printf("\nReading transit lines...");

while( (fgets(&InputString[0], MAXSTR, fp)) != NULL) {
	c1=c2=0;
	slen = strlen(InputString);

	if( (InputString[0] == 'c') || (InputString[0] == 't') )
		goto NEXTLINE;

	if(InputString[0] == 'a') {
		NumRoutes++;
		FoundNodes = FALSE;
		TransitLine = ((struct LineDesc *) malloc (sizeof(struct LineDesc)));

		for(i=0; i <= MAXDIR; i++)
			TransitLine->Dir[i] = 0;

		if(TransitLine == NULL) {
			printf ("\nerror: out of memory, line# %d\n", NumRoutes);
			return;
			}
		if(NumRoutes > MAXROUTES) {
			printf ("\nerror: too many transit lines found.\n");
			return;
			}

		/* transit line id */
		c1 = 1;  c2 = c1;
		while( (InputString[c2] != '\'') && (c2 < slen) )
			c2++;
		c2++;  c1 = c2;
		while( (InputString[c2] != '\'') && (c2 < slen) )
			c2++;

		strncpy(TransitLine->Line,&InputString[c1],(c2-c1));
		TransitLine->Line[c2-c1] = '\0';

		/* transit line mode */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;

		TransitLine->cMode = InputString[c2];

		/* vehicle type */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;

		Value[0] = InputString[c2];
		Value[1] = '\0';
		TransitLine->VehTyp = atoi(Value);

		/* headway */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;
		c1 = c2;
		while( (InputString[c2] != ' ') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		TransitLine->H1 = atof(Value);

		/* default speed */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;
		c1 = c2;
		while( (InputString[c2] != ' ') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		TransitLine->S = atof(Value);

		/* line description */
		c2++;
		while( (InputString[c2] != '\'') && (c2 < slen) )
			c2++;
		c2++; c1 = c2;
		while( (InputString[c2] != '\'') && (c2 < slen) )
			c2++;

		strncpy(TransitLine->Desc,&InputString[c1],(c2-c1));
		TransitLine->Desc[c2-c1] = '\0';
		/* ut1 field */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;
		c1 = c2;
		while( (InputString[c2] != ' ') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		TransitLine->td1 = atof(Value);

		/* ut2 field */
		c2++;
		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;
		c1 = c2;
		while( (InputString[c2] != ' ') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		TransitLine->td2 = atof(Value);

		/* ut3 field */
		c2++;
      while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;
		c1 = c2;
      while( (InputString[c2] != ' ') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		TransitLine->td3 = atof(Value);

		TrLine[NumRoutes] = TransitLine;

		/* set default dwell time and stop flags */
		dwell = 0.01;
		Stop  = TRUE;
		CurDir = 1;

		goto NEXTLINE;
		} /* if "a" */

	/* move to next field */
	while(c2 < slen) {

		while( (InputString[c2] == ' ') && (c2 < slen) )
			c2++;

		if(! isdigit(InputString[c2]) ) {

			/* dwell time */
			if( (InputString[c2] == 'd') && (InputString[c2+2] == 't') ) {
				c2 += 4; c1 = c2;
				while( (InputString[c2] == ' ') && (c2 < slen) )
					c2++;

				special = ' ';
				if( (! isdigit(InputString[c2])) && (InputString[c2] != '.') ) {
					special = InputString[c2];
					c2++;
					}

				while( (InputString[c2] != ' ') && (c2 < slen) )
					c2++;

				strncpy(Value,&InputString[c1],(c2-c1));
				Value[c2-c1] = '\0';
				dwell = atof(Value);

				if(dwell > 0)
					Stop = TRUE;

				/* modify stop based on special characters */
				if(special == '#')
					Stop = FALSE;
				else
				if(special == '+')
					Stop = TRUE;
				else
				if(special == '*')
					Stop = TRUE;

				} /* if dwell time */

			/* layover */
			else
			if( (InputString[c2] == 'l') && (InputString[c2+2] == 'y') ) {
				c2 += 4; c1 = c2;
				while( (InputString[c2] == ' ') && (c2 < slen) )
					c2++;

				/* read over layover value */
				while( (InputString[c2] != ' ') && (c2 < slen) )
					c2++;

				CurDir++;
				if(CurDir > MAXDIR)
					CurDir = MAXDIR;

				} /* if layover */

			else {

				/* what ever it is - skip it */
				while( (InputString[c2] != ' ') && (c2 < slen) )
					c2++;
				}

			} /* ! isdigit */

		else {

			/* we have a node number */
			c1 = c2;
			while( (InputString[c2] != ' ') && (c2 < slen) )
				c2++;

			strncpy(Value,&InputString[c1],(c2-c1));
			Value[c2-c1] = '\0';

			RealNode = atol(Value);

			if(RealNode != 0) {
				Chain = ((struct RouteList *) malloc (sizeof(struct RouteList)));
				if(Chain == NULL) {
					printf ("\nerror: out of memory, line# %d\n",NumRoutes);
					return;
					}

				if(Stop)
					RealNode = (-1*RealNode);

				Chain->next = NULL;
				Chain->Node = RealNode;
				Chain->Dwell= dwell;
				Chain->Dir  = CurDir;

				if(! FoundNodes) {
					TrLine[NumRoutes]->Route = Chain;
					FoundNodes = TRUE;
					}
				else
					add_to_route(TrLine[NumRoutes]->Route, Chain);
				}
			}

		c2++;
		} /* while c2 < slen */

	NEXTLINE:
	;
	} /* while ! EOF */

printf("%d found\n",NumRoutes);
}

/*************************************************************************/
void usage(void)
{

run_header();

printf("\nSee written documentation for further details.\n");
printf("\nUSAGE:  %s  [control-file]\n", ProgName);
}

/*************************************************************************/
void  run_header()
{
int i;

/*clrscr();*/
for(i=1; i <=20; i++)
	printf("\n");
printf("%s (TM) TRANSIT WALK LINK GENERATION PROGRAM\n",ProgName);
printf("Ver %s  Rel %s  (%s-Bit Version)\n", VER, REL, BIT);
for(i=1; i < 52; i++)
	printf("-");
printf("\n");
}

/*************************************************************************/
void  rpt_header(FILE *ptr)
{
int i;

fprintf(ptr,"%s (TM) TRANSIT WALK LINK GENERATION PROGRAM\n",ProgName);
fprintf(ptr,"Ver %s  Rel %s  (%s-Bit Version)\n", VER, REL, BIT);
for(i=1; i < 52; i++)
	fprintf(ptr,"-");
fprintf(ptr,"\n");
fflush(ptr);
}

/*************************************************************************/
void read_m2cents(void)
{
int  lines, endfile;

CentCount = lines = 0;

if( (iptr = fopen(CentroidFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",CentroidFile);
	exit(1);
	}

/* skip "t" cards and blank lines - position pointer to read centroids */
do {
	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	} while ( (linebuf[2] != '*') && (endfile != EOF) );

if(endfile == EOF) {
	printf("\nerror: file \"%s\" ended suddenly.\n",CentroidFile);
	exit(1);
	}

/* start reading centroids */
while((linebuf[2] == '*') && (endfile != EOF) ) {
	if(linebuf[1] != 'a')
		break;
	CentCount++;
	if(CentCount > NumCentroids) {
		printf("\nerror: more than %d centroids found.\n", NumCentroids);
		exit(1);
		}

	if(sscanf(&linebuf[3]," %ld %f %f %f %f %f",
			&cent[CentCount].num,
			&cent[CentCount].x,
			&cent[CentCount].y,
			&cent[CentCount].mindist,
			&cent[CentCount].maxdist,
			&cent[CentCount].maxlinks) < 3) {
		printf("\nerror: in \"%s\" invalid file format, line %d\n",
					CentroidFile, lines);
		exit(1);
		}

	cent[CentCount].x = cent[CentCount].x / NetworkScale;
	cent[CentCount].y = cent[CentCount].y / NetworkScale;

	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	}

fclose(iptr);
}

/*************************************************************************/
void read_m2nodes(void)
{
int  lines, endfile;
long n;

NodeCount = lines = 0;

if( (iptr = fopen(NodeFile,"r")) == NULL ) {
	printf("\nerror: opening file \"%s\" for reading.\n",NodeFile);
	exit(1);
	}

/* skip "t" cards and blank lines - position pointer to read nodes */
do {
	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	} while ( (linebuf[1] != 'a') && (endfile != EOF) );

if(endfile == EOF) {
	printf("\nerror: file \"%s\" ended suddenly.\n",NodeFile);
	exit(1);
	}

/* start reading nodes - first one has been read */
while( (linebuf[1] == 'a') && (endfile != EOF) ) {
	sscanf(&linebuf[3]," %ld",&n);

	if(n > HiNodeNumber) {
		printf("\nerror: more than %d nodes found.\n", HiNodeNumber);
		exit(1);
		}

	if(sscanf(&linebuf[3]," %ld %f %f",
		&node[n].num,
		&node[n].x,
		&node[n].y) < 3) {
		printf("\nerror: in \"%s\" invalid file format, line %d\n",
			NodeFile,lines);
		exit(1);
		}
	node[n].x = node[n].x / NetworkScale;
	node[n].y = node[n].y / NetworkScale;

	endfile = fget_line(&linebuf[1],MAXSTR,iptr);
	lines++;
	NodeCount++;
	}

fclose(iptr);
}

/*************************************************************************/
void pick_frto(char *tempbuf, int *from, int *to, int *length)
{
int err = FALSE;
                          
if( (sscanf(tempbuf," %d - %d", from, to)) < 2)
  err = TRUE;
if(*to < *from)
  err = TRUE;
if( (*from <= 0) || (*to <= 0) )
  err = TRUE;

*length = (*to - *from) + 1;

if(err) {
	printf("\nerror: reading line:\n=>%s", tempbuf);
	exit(1);
	}

}

/*************************************************************************/
void read_tplines(void)
{
char InputString[MAXSTR];
char Value[15];
long RealNode;
float dwell;
int FoundNodes, CurDir;
int i, c1, c2, slen, n;
struct RouteList *Chain;
struct LineDesc  *TransitLine;
FILE *fp;

NumRoutes = 0;

/* Open the Transit Line file for reading */
if ((fp = fopen(TransitFile, "r")) == NULL) {
	printf("\nerror: opening file \"%s\" for reading.\n",TransitFile);
	exit(1);
	}

printf("\nReading transit lines...");

while( (fgets(&InputString[0], MAXSTR, fp)) != NULL) {
	c1 = 0;
	slen = strlen(InputString);

	if( str_index(InputString, "&ROUTE") >= 0) {
		NumRoutes++;
		FoundNodes = FALSE;
		TransitLine = ((struct LineDesc *) malloc (sizeof(struct LineDesc)));

		if(TransitLine == NULL) {
			printf ("\nerror: out of memory, route# %d\n",NumRoutes);
			return;
			}

		for(i=0; i <= MAXDIR; i++)
			TransitLine->Dir[i] = 0;

		/* transit line number */
		if( (c1=(str_index(InputString, "L="))) >= 0) {
			c1 += 2;  c2 = c1;
			while( (InputString[c2] == ' ') && (c2 < slen) )
				c2++;
			c1 = c2;
			while( (InputString[c2] != ',') && (c2 < slen) )
				c2++;
			strncpy(TransitLine->Line,&InputString[c1],(c2-c1));
			TransitLine->Line[c2-c1] = '\0';
			}

		/* transit line mode */
		if( (c1=(str_index(InputString, "M="))) >= 0) {
			c1 += 2;  c2 = c1;
			while( (InputString[c2] != ',') && (c2 < slen) )
				c2++;
			strncpy(Value,&InputString[c1],(c2-c1));
			Value[c2-c1] = '\0';
			TransitLine->iMode = atoi(Value);
			if(TransitLine->iMode > 999) {
				printf ("\nerror: invalid mode number, route# %d\n",NumRoutes);
				exit(-1);
				}

			}

		/* transit line description */
		if( (c1=(str_index(InputString, "ID="))) >= 0) {
			c1 += 2;  c2 = c1;
			while( (InputString[c2] != '\'') && (c2 < slen) )
				c2++;

			c2++;  c1 = c2;
			while( (InputString[c2] != '\'') && (c2 < slen) )
				c2++;

			strncpy(TransitLine->Desc,&InputString[c1],(c2-c1));
			TransitLine->Desc[c2-c1] = '\0';
			}

		TrLine[NumRoutes] = TransitLine;

		/* set default dwell time and direction flags */
		dwell = 0.01;
		CurDir = 1;

		} /* if "&ROUTE" */

	/* move to first node */
	if( (n=(str_index(InputString, "N="))) >= 0) {
		FoundNodes = TRUE;

		c1 = n + 2;  c2 = c1;
		while( (InputString[c2] != ',') && (c2 < slen) )
			c2++;
		strncpy(Value,&InputString[c1],(c2-c1));
		Value[c2-c1] = '\0';
		c1 = c2 + 1;

		RealNode = atol(Value);

		Chain = ((struct RouteList *) malloc (sizeof(struct RouteList)));
		if(Chain == NULL) {
			printf ("\nerror: out of memory, route# %d\n",NumRoutes);
			return;
		  }

		Chain->next = NULL;
		Chain->Node = RealNode;
		Chain->Dwell= dwell;
		Chain->Dir  = CurDir;

		TrLine[NumRoutes]->Route = Chain;
		}

	/* look for nodes */
	while( (c1 < slen) && (FoundNodes) ) {

		c2 = c1;
		while( ( (InputString[c2] != '-') && (! isdigit(InputString[c2])) ) &&
				 (c2 < slen) )
			c2++;

		c1 = c2;
		while( (InputString[c2] != ',') && (c2 < slen) )
			c2++;

		strncpy(Value,&InputString[c1],(c2-c1));
      Value[c2-c1] = '\0';
		c1 = c2 + 1;

		RealNode = atol(Value);

		if(RealNode != 0) {
			Chain = ((struct RouteList *) malloc (sizeof(struct RouteList)));
			if(Chain == NULL) {
				printf ("\nerror: out of memory, route# %d\n",NumRoutes);
				return;
				}
         Chain->next = NULL;
			Chain->Node = RealNode;
			Chain->Dwell= dwell;
			Chain->Dir  = CurDir;

			add_to_route(TrLine[NumRoutes]->Route, Chain);
			}

		} /* while < slen) */

	} /* while ! EOF */

printf("%d found\n",NumRoutes);

}

/*************************************************************************/
void write_link(long cent, long cnode, float dist)
{
char FormatString[MAXSTR];
long ldist, ltime;
float fdist;

if(LinkFormat == 'e') {
	if(DeleteLinks) {

		sprintf(FormatString,"d %%ld,%%ld\n");
		switch(newlink.direction) {
			case 't':
				fprintf(optr,FormatString,cent,cnode);
				fprintf(optr,FormatString,cnode,cent);
				break;
			case 'i':
				fprintf(optr,FormatString,cnode,cent);
				break;
			case 'o':
				fprintf(optr,FormatString,cent,cnode);
				break;
			}
		} /* DeleteLinks */

	sprintf(FormatString,"a %%ld,%%ld,%%.4f,%%s,%%d,%%.1f,%%d,0,0,0\n");

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,dist,newlink.modesout,newlink.type,
				newlink.lanes,newlink.vdf);
				LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,dist,newlink.modesin,newlink.type,
				newlink.lanes,newlink.vdf);
			 LinkCount++;
			 break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,dist,newlink.modesin,newlink.type,
				newlink.lanes,newlink.vdf);
			LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,dist,newlink.modesout,newlink.type,
				newlink.lanes,newlink.vdf);
			LinkCount++;
			break;
		}

	} /* if LinkFormat == e */
else
if(LinkFormat == 't') {
	sprintf(FormatString,"1%%5ld%%5ld %%-2s        %%4ld   %%3ld   %%3ld   %%3ld1\n");

	ldist = dist*10;
	ltime = (dist/WalkSpeed)*60*10;

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,ldist,ltime,ltime,ltime);
				LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,ldist,ltime,ltime,ltime);
				LinkCount++;
			 LinkCount++;
			 break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,ldist,ltime,ltime,ltime);
				LinkCount++;
			 LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,ldist,ltime,ltime,ltime);
				LinkCount++;
			break;
		}

	} /* if LinkFormat == t */
else
if(LinkFormat == 'i') {

	sprintf(FormatString,"1%%5ld%%5ld %%-2s         %%.2f %%4.1f            1\n");

	fdist = dist;

	switch(newlink.direction) {
		case 't':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,fdist,WalkSpeed);
			LinkCount++;
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,fdist,WalkSpeed);
			LinkCount++;
			break;
		case 'i':
			fprintf(optr,FormatString,
				cnode,cent,newlink.modesin,fdist,WalkSpeed);
			LinkCount++;
			break;
		case 'o':
			fprintf(optr,FormatString,
				cent,cnode,newlink.modesout,fdist,WalkSpeed);
			LinkCount++;
			break;
		}

	} /* if LinkFormat == i */

}

